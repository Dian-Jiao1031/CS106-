from http.server import HTTPServer, SimpleHTTPRequestHandler, test as test_orig
import sys
import os
import glob
import threading
import time

labels = ["I", "LOVE", "S", "U", "T", "E", "C", "H", "CLEAR"]
res_prefix = "1_" # 结果的前缀形式
# res_prefix = "hh_" # wanli
output_path = "./text.txt" # 输出用于前端识别的文本路径
# input_prefix = "./" # wanli
input_prefix = "D:/MyLand/cs106/yolov5/runs/detect/exp99/"
input_path = input_prefix + "labels/" # 所有结果的路径
max_pro = 0 # 大于这个概率才会识别为有效结果

class dealResults (threading.Thread):
    def __init__(self, threadID, name, counter):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.counter = counter
    def run(self):
        num = 0 # 当前已经处理的帧数
        max_num = 0 # 最大需要处理的帧数
        last_idx = -1 # 上一个识别到的下标
        while(1):
            try:
                # 索引当前所有文件的列表
                fs_name = sorted(glob.iglob(input_path + "*.txt"), key=os.path.getmtime)
                fs_num = len(fs_name)
                max_num = int(fs_name[fs_num - 1][50:-4])
                # max_num = int(fs_name[fs_num - 1][12:-4])
                # 如果最大的数目比当前处理过的还要大，说明还有帧需要处理
                if(max_num > num):
                    # 那么读取当前这些文本的内容
                    for i in range(num, max_num):
                        print(i, max_num)
                        try:
                            path = input_path + res_prefix + str(i) + ".txt"
                            f = open(path, 'r')
                            info_array = f.read().split(" ")
                            f.close()
                            print(info_array)
                            cur_idx = int(info_array[0])
                            cur_pro = float(info_array[1])
                            
                            # 如果当前这个概率小于预定概率，就不处理
                            if(cur_pro <= max_pro):
                                continue
                            rf = open(output_path, 'w')
                            rf.write(labels[cur_idx] + " " + str(cur_pro))
                            rf.close()

                            # 如果这个下标和上一个不一样
                            if(cur_idx != last_idx):
                                print(labels[cur_idx])
                                last_idx = cur_idx
                                # rf = open(output_path, 'w')
                                # rf.write(labels[cur_idx], cur_pro)
                                # rf.close()
                            # 这个下标和上一个是一样的， 那么不做处理了
                        except:
                            # 这帧的数据丢了
                            continue
                    num = max_num
                else:
                    # 不做处理，当前无新文本生成
                    print("", end="")
            except:
                print("", end="")
                # last_num = 0

class openServer (threading.Thread):
    def __init__(self, threadID, name, counter):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.counter = counter
    def run(self):
        openFileServer(CORSRequestHandler, HTTPServer)


def openFileServer (*args):
    test_orig(*args, port=int(sys.argv[1]) if len(sys.argv) > 1 else 8000)

class CORSRequestHandler (SimpleHTTPRequestHandler):
    def end_headers (self):
        self.send_header('Access-Control-Allow-Origin', '*')
        SimpleHTTPRequestHandler.end_headers(self)


if __name__ == '__main__':
    thread1 = openServer(1, "T-2", 1)    
    thread2 = dealResults(2, "T-1", 2)

    thread1.start()    
    thread2.start()
    thread1.join()
    thread2.join()
